import React from 'react'

import './c_android-compact1.css'

const CAndroidCompact1 = (props) => {
  return (
    <div className="c_android-compact1-frame">
      <div className="c_android-compact1-text">
        <p className="c_android-compact1-text1">Login to your Account</p>
      </div>
      <img
        src="./assets/0520a1ab307fe73e863b044e310522e3.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact1-rectangle"
      />
      <img
        src="./assets/72b772867c734d779befc9e92ea2e5e6.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact1-rectangle1"
      />
      <img
        src="./assets/371c69895ec495bb0ba900238d0dfde0.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact1-rectangle2"
      />
      <div className="c_android-compact1-text2">
        <p className="c_android-compact1-text3">Or login with</p>
      </div>
    </div>
  )
}

export default CAndroidCompact1
