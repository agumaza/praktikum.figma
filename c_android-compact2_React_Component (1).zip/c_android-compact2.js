import React from 'react'

import './c_android-compact2.css'

const CAndroidCompact2 = (props) => {
  return (
    <div className="c_android-compact2-frame">
      <div className="c_android-compact2-text">
        <p className="c_android-compact2-text1">Create your Account</p>
      </div>
      <img
        src="./assets/ed64a8d81edf72b4bbb2ed482980a698.png"
        alt="rectangle"
        width={31}
        height={31}
        className="c_android-compact2-rectangle"
      />
      <img
        src="./assets/6267b9afbdfde1c6e59b4b534e9d83d5.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact2-rectangle1"
      />
      <img
        src="./assets/7ad0601097aba178ba8e9cf9192bacad.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact2-rectangle2"
      />
      <img
        src="./assets/783e416ddc3e8a37c5a005b706bf64a4.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact2-rectangle3"
      />
      <div className="c_android-compact2-text2">
        <p className="c_android-compact2-text3">Or login with</p>
      </div>
    </div>
  )
}

export default CAndroidCompact2
