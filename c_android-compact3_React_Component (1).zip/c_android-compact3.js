import React from 'react'

import './c_android-compact3.css'

const CAndroidCompact3 = (props) => {
  return (
    <div className="c_android-compact3-frame">
      <img
        src="./assets/85c290f7c627550a8f66ca8eb1391a5d.png"
        alt="rectangle"
        width={90}
        height={90}
        className="c_android-compact3-rectangle"
      />
      <img
        src="./assets/4809c37fcbfb2cd450ef4bc3c8ec942c.png"
        alt="rectangle"
        width={90}
        height={90}
        className="c_android-compact3-rectangle1"
      />
      <img
        src="./assets/8bd4422b477666058f1f3e81d8abb44c.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact3-rectangle2"
      />
      <img
        src="./assets/c09b837b59bdce8e5093b0ce897343a3.png"
        alt="rectangle"
        width={50}
        height={50}
        className="c_android-compact3-rectangle3"
      />
      <img
        src="./assets/37b97e8e6697ef31a0091dcaf863cb69.png"
        alt="rectangle"
        width={50}
        height={50}
        className="c_android-compact3-rectangle4"
      />
      <img
        src="./assets/ec4b8f25e63e62c7bed6dd6852c26fc7.png"
        alt="rectangle"
        width={400}
        height={500}
        className="c_android-compact3-rectangle5"
      />
    </div>
  )
}

export default CAndroidCompact3
